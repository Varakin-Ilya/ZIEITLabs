const videoSelectBtn = document.getElementById("videoSelectBtn");
const { desktopCapturer, remote } = require("electron");
const { Menu } = remote;

videoSelectBtn.onclick = getVideoSources;

async function getVideoSources(){
  const inputSources = await desktopCapturer.getSources({
    types: ["window", "screen"]
  });
  console.log(inputSources);
  const videoOptionsMenu = Menu.buildFromTemplate(
    inputSources.map(source => {
      return{
        label: source.name,
        click:() => selectSource(source)
      };
    })
  );

  videoOptionsMenu.popup();
}