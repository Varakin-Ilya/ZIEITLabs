import {Component} from '@angular/core'

@Component({
  selector: 'app-about-extra',
  templateUrl: './about-extra.component.html',
  styleUrls: ['./about-extra.component.scss']
})
export class AboutExtraComponent {
}
